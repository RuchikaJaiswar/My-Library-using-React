import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import './App.css';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Editicon from '@mui/icons-material/Edit';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
const bookObject={
  title:'',
  author:'',
  isbn:'',
  year:'',
  coverurl:'',
  blurb:''

}


function App() {
  const [modal, setmodal] = useState(bookObject)
  const [booklist, setbooklist] = useState([])
  const [edit, setedit] = useState(false)
  const changeHandler = (e) => {
    const value = e.target.value
    setmodal(modal=>  ({
      ...modal,
      [e.target.name]: value
    }))
  }
  const AddBook = () => {
    if(edit){
const updatebooklist = booklist.map((row) => row.id === modal.id ? modal:row);
setbooklist(updatebooklist)
setedit(false)
setmodal(bookObject)
    }
    else{
       let listItems = booklist;
       const item = {
        id:booklist.length,
        ...modal
       }
       listItems = [...booklist , item]
       setbooklist(listItems)
  }}

  const ClearData = () => [
        setmodal(bookObject)
  ] 

const deleterow = (id) => {
  const filtered= booklist.filter(item => item.id !=id)
  setbooklist(filtered)
}

const editrow = (data) => {
  setmodal(data)
  setedit(true)
}

  console.log(modal)
  return (
    <div className="App">
      <Box sx={({n: 2, p:2, border: "2px solid black"})}>
        <TextField label="Title" name="title" variant="outlined" onChange={changeHandler} style={{width: "100%"}}  sx={{mr: 2, mb:2}} value={modal.title} />
        <TextField label="Author" name="author" variant="outlined"  onChange={changeHandler} style={{width: "100%"}} sx={{mr: 2, mb:2}} value={modal.author}/>
        <TextField label="ISBN " name="isbn" variant="outlined" onChange={changeHandler} style={{width: "100%"}} sx={{mr: 2, mb:2}} value={modal.isbn} />
        <TextField label="Year" name="year" variant="outlined" onChange={changeHandler} style={{width: "100%"}} sx={{mr: 2, mb:2}} value={modal.year}/>
        <TextField label="Cover image URL" name="coverurl" variant="outlined" onChange={changeHandler} style={{width: "100%"}} sx={{mr: 2, mb:2}} value={modal.coverurl}/>
        <TextField label="Blurb" name="blurb" variant="outlined" onChange={changeHandler} style={{width: "100%"}} sx={{mr: 2, mb:2}} value={modal.blurb}/>
      </Box>
      <Box textAlign="center">
        <Button variant='contained' color="success" onClick={AddBook}>
          {edit ? "Update" : "Submit" }
        </Button>
        <Button variant='contained' sx={{ml: 3}} onClick= {ClearData}>
          Clear
        </Button>
      </Box>

      <Box sx={{n: 2, p:2, border: "3px solid pink"}}>
        <table  style={{width: "100%"}}>
          <tr style={{background: "grey"}}> 
            <th>Title</th>
            <th>Author</th>
            <th>ISBN</th>
            <th>Year</th>
            <th>Cover</th>
            <th>Blurb</th>
            <th>Action</th>
          </tr>
          { booklist && booklist.map((row,index) =>
          <tr>
            <td>{row.title}</td>
            <td>{row.author}</td>
            <td>{row.isbn}</td>
            <td>{row.year}</td>
            <td>{row.coverurl}</td>
            <td>{row.blurb}</td>
            <td><Editicon  style ={{color: "green" , cursor:"pointer"}} onClick={()=> editrow(row)}/>
            <DeleteForeverIcon style ={{color: "red" , cursor:"pointer"}} onClick={() => deleterow(row.id)}/></td>
            
          </tr>
          )}
        </table>
      </Box>
    </div>
  );
}

export default App;
